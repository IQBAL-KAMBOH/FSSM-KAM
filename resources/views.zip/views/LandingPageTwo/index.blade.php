<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <title>FSSM</title>
    <style>
      .text-justify {
         text-align: justify;
      }
      .my-bg{
        background-color: rgb(3, 3, 48);
      }
    </style>
            <style>
  #navbutton {
    position: fixed;
    top: 10px;
    right: 15px;
  }
  .mynavli{
    background: #ff00cc;  /* fallback for old browsers */
background: -webkit-linear-gradient(to right, #333399, #ff00cc);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to right, #333399, #ff00cc); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
  color:white;
  }
 .mynav{
  
 }

   
</style> 

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/templatemo-space-dynamic.css">
    <link rel="stylesheet" href="assets/css/animated.css">
    <link rel="stylesheet" href="assets/css/owl.css">
<!--
    
TemplateMo 562 Space Dynamic

https://templatemo.com/tm-562-space-dynamic

-->
  </head>

<body class="my-bg">

  <!-- ***** Preloader Start ***** -->
  <!-- <div id="js-preloader" class="js-preloader">
    <div class="preloader-inner">
      <span class="dot"></span>
      <div class="dots">
        <span></span>
        <span></span>
        <span></span>
      </div>
    </div>
  </div> -->
  <!-- ***** Preloader End ***** -->

  <!-- ***** Header Area Start ***** -->
  <header class="header-area header-sticky wow slideInDown"  data-wow-duration="0.75s" data-wow-delay="0s">
    <div class="pl-2">
      <div class="row" >
        <div class="col-12">
          <nav class="main-nav" >
            <div class="text-left justify-content-left">
              <a href="/store" class="btn btn-light mt-1 d-lg-none d-md-none d-xl-none text-start">Online Store</a>
            </div>
            <!-- ***** Logo Start ***** -->
            <a href="/" class="p-2">
              
            <img src="assets/images/fssm-logo.png" style="width: 200px;min-height:70px;" alt="">
              
            </a>
            <!-- ***** Logo End ***** -->
            <!-- ***** Menu Start ***** -->
            <ul class="nav">
              <li class="scroll-to-section"><a href="#top" class="active">Home</a></li>
              <li class="scroll-to-section text-light"><a href="#about">About Us</a></li>
              <li class="scroll-to-section"><a href="#services">Services</a></li>
              <li class="scroll-to-section"><a href="#portfolio">Portfolio</a></li>
              <li class="scroll-to-section"><a href="#blog">Blog</a></li> 
              <li class="scroll-to-section"><a href="#contact">Message Us</a></li> 
              <li class="scroll-to-section"><a href="/store">Store</a></li> 
              <li class="scroll-to-section"><a href="/login">Login</a></li> 
              
              <li class="scroll-to-section"><div class="main-red-button"><a href="#contact">Contact Now</a></div></li> 

            </ul> 
          
            <button id="navbutton" class="btn btn-outline-light d-lg-none d-md-none d-xl-none text-right"  data-toggle="modal" data-target="#exampleModal">=</button>

            <!-- ***** Menu End ***** -->
          </nav>
        </div>
      </div>
    </div>
  </header>
  <!-- ***** Header Area End ***** -->

  <div class="main-banner wow fadeIn" id="top" data-wow-duration="1s" data-wow-delay="0.5s">
    <div class="container">
      <div class="row">
        <div class="col-lg-12">
          <div class="row">
            <div class="col-lg-6 align-self-center">
              <div class="left-content header-text wow fadeInLeft" data-wow-duration="1s" data-wow-delay="1s">
                <!-- <h6 class="text-light">Welcome to <span class="text-info">Future Secure</span> Sales & Marketing</h6> -->
                <h2 class="text-light">Future <em>Secure</em> Sales &amp; Marketing</h2>
                <p class="text-light"> You are warmly welcome here </p>
                <!-- <form id="search" action="#" method="GET">
                  <fieldset>
                    <input type="address" name="address" class="email" placeholder="Your website URL..." autocomplete="on" required>
                  </fieldset>
                  <fieldset>
                    <button type="submit" class="main-button">Analyze Site</button>
                  </fieldset>
                </form> -->
              </div>
            </div>
            <div class="col-lg-6">
              <div class="right-image wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.5s">
                <img src="assets/images/banner-right-image.png" alt="team meeting">
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div id="about" class="about-us section">
    <div class="container">
      <div class="row">
        <div class="col-lg-4">
         <div class="item wow fadeIn card text-center shadow" data-wow-duration="1s" data-wow-delay="0.5s">
                
                    <img src="assets/images/ceo.png" alt="reporting">
                  
                
                    <h4 class="mt-4">Founder & CEO</h4>
                    <p>Syed Zeeshan Tariq</p>
                    <p>June 1, 2023 </p>
                
                </div>
        </div>
        <div class="col-lg-8 align-self-center">
          <div class="services">
            <div class="row">
              <div class="col-lg-6">
                
              </div>
              <!-- <div class="col-lg-6">
                <div class="item wow fadeIn" data-wow-duration="1s" data-wow-delay="0.7s">
                  <div class="icon">
                    <img src="assets/images/service-icon-02.png" alt="">
                  </div>
                  <div class="right-text">
                    <h4>Online Shoping</h4>
                    <p>Lorem ipsum dolor sit amet, ctetur aoi adipiscing eliter</p>
                  </div>
                </div>
              </div>
              <div class="col-lg-6">
                <div class="item wow fadeIn" data-wow-duration="1s" data-wow-delay="0.9s">
                  <div class="icon">
                    <img src="assets/images/service-icon-03.png" alt="">
                  </div>
                  <div class="right-text">
                    <h4>Developement</h4>
                    <p>Lorem ipsum dolor sit amet, ctetur aoi adipiscing eliter</p>
                  </div>
                </div>
              </div>
              <div class="col-lg-6">
                <div class="item wow fadeIn" data-wow-duration="1s" data-wow-delay="1.1s">
                  <div class="icon">
                    <img src="assets/images/service-icon-04.png" alt="">
                  </div>
                  <div class="right-text">
                    <h4>Marketing</h4>
                    <p>Lorem ipsum dolor sit amet, ctetur aoi adipiscing eliter</p>
                  </div>
                </div> -->
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div id="services" class="our-services section">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 align-self-center  wow fadeInLeft" data-wow-duration="1s" data-wow-delay="0.2s">
          <div class="left-image">
            <img src="assets/images/services-left-image.png" alt="">
          </div>
        </div>
        <div class="col-lg-6 wow fadeInRight" data-wow-duration="1s" data-wow-delay="0.2s">
          <div class="section-heading p-4">
            <h2 class="text-light">Grow yourself <em>with</em> our <em>services</em>  &amp; <span>Project</span> Ideas</h2>
            <p class="text-light text-justify">The company FUTURE SECURE is working for those people who cannot afford their own business and searching for best platform with best plan. No matters what is age, education and gender. FUTURE SECURE make a common man personally and professionally very strong and make him able to earn money at home.</p>
          </div>
          <div class="row">
            <div class="col-lg-12">
              <div class="first-bar progress-skill-bar p-4">
                <h4 class="text-info">Scope</h4>
                
                <p class="text-light text-justify">Since online business is growing day by day in Pakistan,a lot of people are trying to start their own business and mostly people choose business side but as Pakistan is developing country not all people can afford to start their own business.But all of people can afford a online business which is with affordable pakages and best plan</p>
              </div>
            
            </div>
            <div class="col-lg-12">
              <div class="second-bar progress-skill-bar p-4">
                <h4 class="text-info">Discover</h4>
                <p class="text-light text-justify">If you are really searching a best platform with best plan and affordable bundles then congratulations you are at best place</p>
                
              </div>
            </div>
            <div class="col-lg-12">
              <div class="third-bar progress-skill-bar  p-4">
                <h4 class="text-info">Digital Learning System</h4>
                <p class="text-light text-justify">The company will help you how you can Brand yourself</p>

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div id="portfolio" class="our-portfolio section">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 offset-lg-3">
          <div class="section-heading  wow bounceIn" data-wow-duration="1s" data-wow-delay="0.2s">
            <h2 class="text-light">See What Our Agency <em>Offers</em> &amp; What We <span>Provide</span></h2>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-3 col-sm-6">
          <a href="javasvript:void(0);">
            <div class="item wow bounceInUp" data-wow-duration="1s" data-wow-delay="0.3s">
             
              <div class="showed-content" style="min-height: 400px;">
                <img src="assets/images/portfolio-image.png" alt="">
                <h4 class=" mt-4">Digital Courses</h4>
              </div>
            </div>
          </a>
        </div>
        <div class="col-lg-3 col-sm-6">
          <a href="javasvript:void(0);">
            <div class="item wow bounceInUp" data-wow-duration="1s" data-wow-delay="0.4s">
             
              <div class="showed-content">
                <img src="assets/images/portfolio-image.png" alt="">
                <h4 class=" mt-4">Opportunity For business</h4>
                
              </div>
            </div>
          </a>
        </div>
        <div class="col-lg-3 col-sm-6">
          <a href="javasvript:void(0);">
            <div class="item wow bounceInUp" data-wow-duration="1s" data-wow-delay="0.5s">
             
              <div class="showed-content">
                <img src="assets/images/portfolio-image.png" alt="">
                <h4 class="mt-4">Different Skills useful in every field of life</h4>
              </div>
            </div>
          </a>
        </div>
        <div class="col-lg-3 col-sm-6">
          <a href="javasvript:void(0);">
            <div class="item wow bounceInUp" data-wow-duration="1s" data-wow-delay="0.6s">
              
              <div class="showed-content">
                <img src="assets/images/portfolio-image.png" alt="">
                <h4 class="mt-4">Life changing trainings by experienced mentor</h4>
              </div>
            </div>
          </a>
        </div>
      </div>
    </div>
  </div>

  <div id="blog" class="our-blog section">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 wow fadeInDown" data-wow-duration="1s" data-wow-delay="0.25s">
          <div class="section-heading">
            <h2 class="text-light">Check <span> Out</span> What Is <em>Trending</em> In Our Latest <span>News</span></h2>
          </div>
        </div>
        <div class="col-lg-6 wow fadeInDown" data-wow-duration="1s" data-wow-delay="0.25s">
          <div class="top-dec">
            <img src="assets/images/blog-dec.png" alt="">
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-lg-6 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.25s">
          <div class="left-image">
            <a href="#"><img src="assets/images/big-blog-thumb.jpg" alt="Workspace Desktop"></a>
            <div class="info">
              <div class="inner-content">
                <!-- <ul>
                  <li><i class="fa fa-calendar"></i> 24 Mar 2021</li>
                  <li><i class="fa fa-users"></i> TemplateMo</li>
                  <li><i class="fa fa-folder"></i> Branding</li>
                </ul>
                <a href="#"><h4>SEO Agency &amp; Digital Marketing</h4></a>
                <p>Lorem ipsum dolor sit amet, consectetur and sed doer ket eismod tempor incididunt ut labore et dolore magna...</p>
                <div class="main-blue-button">
                  <a href="#">Discover More</a>
                </div> -->
              </div>
            </div>
          </div>
        </div>
        <div class="col-lg-6 wow fadeInUp" data-wow-duration="1s" data-wow-delay="0.25s">
          <div class="right-list">
            <ul>
              <li>
                <div class="left-content align-self-center p-4">
                  
                  <a class="text-light" href="#"><h4 class="text-info">Vision</h4></a>
                  <p class="text-light ">Makes people skilled and creative through a training process to become Digital Entrepreneurs.
                    Empowering the community by creating a community-based marketplace where people's best skills, services are accessible to people.</p>
                </div>
                <div class="right-image mt-4">
                  <a href="#"><img src="assets/images/vision.png" alt=""></a>
                </div>
              </li>
              <li>
                <div class="left-content align-self-center p-4">
             
                  <a class="text-light" href="#"><h4 class="text-info ">Purpose</h4></a>
                  <p class="text-light text-info">Its aim is to bring out talented and creative people. To eliminate unemployment</p>
                </div>
                <div class="right-image">
                  <a href="#"><img src="assets/images/purpose.jpg" alt=""></a>
                </div>
              </li>
             
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>

  <div id="contact" class="contact-us section">
    <div class="container">
      <div class="row">
        <div class="col-lg-6 align-self-center wow fadeInLeft" data-wow-duration="0.5s" data-wow-delay="0.25s">
          <div class="section-heading">
            <h2>Feel Free To Send Us a Message </h2>
          
              <a aria-label="Chat on WhatsApp" href="https://wa.me/+923209450815" style="max-width:50px !important;"><img src="images/WhatsAppButtonGreenSmall.png" style="max-width:200px !important;" alt=""></a>
          </div>
        </div>
        <div class="col-lg-6 wow fadeInRight" data-wow-duration="0.5s" data-wow-delay="0.25s">
          <form id="contact" action="" method="post">
            <div class="row">
              <div class="col-lg-6">
                <fieldset>
                  <input type="name" name="name" id="name" placeholder="Name" autocomplete="on" required>
                </fieldset>
              </div>
              <div class="col-lg-6">
                <fieldset>
                  <input type="surname" name="surname" id="surname" placeholder="Surname" autocomplete="on" required>
                </fieldset>
              </div>
              <div class="col-lg-12">
                <fieldset>
                  <input type="text" name="email" id="email" pattern="[^ @]*@[^ @]*" placeholder="Your Email" required="">
                </fieldset>
              </div>
              <div class="col-lg-12">
                <fieldset>
                  <textarea name="message" type="text" class="form-control" id="message" placeholder="Message" required=""></textarea>  
                </fieldset>
              </div>
              <div class="col-lg-12">
                <fieldset>
                  <button type="submit" id="form-submit" class="main-button ">Send Message</button>
                </fieldset>
              </div>
            </div>
            <div class="contact-dec">
              <img src="assets/images/contact-decoration.png" alt="">
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>

  <footer id="footer" class="footer">

    <div class="container">
      <div class="row gy-4">
        <div class="col-lg-5 col-md-12 footer-info">
          <img src="assets/images/fssm-logo.png" style="width: 200px;height: 200px;margin-top: 0px;" alt="">
          <a href="index.html" class="logo d-flex align-items-center">
            <span class="text-light">Future Secure Sales and Marketing</span>
          </a>
          <p class="text-light text-justify">The company FUTURE SECURE is working for those people who cannot afford their own business and searching for best platform with best plan.
          No matters what is age, education and gender.
          FUTURE SECURE make a common man personally and professionally very strong and make him able to earn money at home.
          </p>
          <div class="social-links  d-flex mt-4">
            <a href="#" class="twitter"><i class="bi bi-twitter"></i></a>
            <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
            <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
            <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></a>
          </div>
        </div>
  
        <div class="col-lg-2 text-light col-6 footer-links">
          <h4>Useful Links</h4>
          <ul >
            
            <li><a href="#top" class="active">Home</a></li>
              <li><a href="#about">About Us</a></li>
              <li><a href="#services">Services</a></li>
              <li><a href="#portfolio">Portfolio</a></li>
              <li><a href="#blog">Blog</a></li> 
              <li><a href="#contact">Message Us</a></li> 
             
          </ul>
        </div>
  
        <div class="col-lg-2 col-6 footer-links">
          <h4 class="text-light">Our Services</h4>
          <ul>
            <li><a href="#">Marketing</a></li>
            <li><a href="#">Trading</a></li>
          </ul>
        </div>
  
        <div class="col-lg-3 col-md-12 footer-contact text-center text-md-start">
      <h4 class="text-light">Contact Us</h4>
      <p class="text-light">
          Tahsil Renala Khurd, District Okara <br><br>
          <strong class="text-light">Phone:</strong>
          <a href="tel:(+92)3209450815">tel:(+92)3209450815</a>
          
            <br>
          <strong class="text-light">Email:</strong> 
          <a href="mailto:admin@fs-sm.co">admin@fs-sm.co</a>
          <br>
      </p>
  </div>
  
  
      </div>
    </div>
  
    <div class="container mt-4">
     
      <div class="credits">
     
        <!-- Designed by <a href="*">5Tech Sol.</a> -->
      </div>
    </div>
  
  </footer>
  <!-- Scripts -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/js/owl-carousel.js"></script>
  <script src="assets/js/animation.js"></script>
  <script src="assets/js/imagesloaded.js"></script>
  <script src="assets/js/templatemo-custom.js"></script>
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<!-- Modal -->
<script>
    function closeM(url){
      
      window.location.href =url;
      $(".close").trigger("click");
      
    }
  </script>
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content mynav" >
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel"></h5>
        <button type="button" class="close mynavli" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true" class="">&times;</span>
        </button>
      </div>
      <div class="modal-body">
           
              <a class="form-control m-1 p-2 pt-3 pb-3 shadow text-center mynavli"  href="#top" onclick="closeM(this.href)" class="active">Home</a>
              <a class="form-control m-1 p-2 pt-3 pb-3 shadow text-center mynavli"  href="#about" onclick="closeM(this.href)">About Us</a>
              <a class="form-control m-1 p-2 pt-3 pb-3 shadow text-center mynavli"  href="#services" onclick="closeM(this.href)">Services</a>
              <a class="form-control m-1 p-2 pt-3 pb-3 shadow text-center mynavli"  href="#portfolio" onclick="closeM(this.href)">Portfolio</a>
              <a class="form-control m-1 p-2 pt-3 pb-3 shadow text-center mynavli"  href="#blog" onclick="closeM(this.href)">Blog</a> 
              <a class="form-control m-1 p-2 pt-3 pb-3 shadow text-center mynavli"  href="#contact" onclick="closeM(this.href)">Message Us</a> 
              <a class="form-control m-1 p-2 pt-3 pb-3 shadow text-center mynavli"  href="/store" onclick="closeM(this.href)">Store</a> 
              <a class="form-control m-1 p-2 pt-3 pb-3 shadow text-center mynavli"  href="/login" onclick="closeM(this.href)">Login</a> 
              <a class="form-control m-1 p-2 pt-3 pb-3 shadow text-center mynavli"  href="/register" onclick="closeM(this.href)">Register</a> 
              <a class="form-control m-1 p-2 pt-3 pb-3 shadow text-center mynavli"  href="#contact" onclick="closeM(this.href)">Contact Now</a> 
              
           

           
      </div>
     
    </div>
  </div>
</div>

</body>
</html>