


                <div id="mySidenav" class="sidenav">
                     <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
             
                              <a href="/digital_cource">Digital Courses</a>
                              <a href="/digital-library">Digital Library</a>
                              <a href="/store">Physical Products</a>
                              <hr class="text-light">
                              <span class="text-center text-warning dropdown-item">Categories</span>
                              @foreach($categories as $link)
                               <a class="dropdown-item" href="#section_{{$link->name}}">{{$link->name}}</a>
                              @endforeach
                  </div>