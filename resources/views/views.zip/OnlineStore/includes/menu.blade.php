<ul>
                           
                              <li><a class="text-light" href="/digital_cource">Digital Courses</a></li>
                              <li><a class="text-light" href="/digital-library">Digital Library</a></li>
                              <li><a class="text-light" href="/store">Physical Products</a></li>
                             
                           </ul>